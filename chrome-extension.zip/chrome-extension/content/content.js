// src/content/content.js
// Entry content script: detect quiz -> detect course -> tai dap an -> match -> highlight + floating badge.
(function () {
  'use strict';

  if (window.tailieuContentLoaded) return;
  window.tailieuContentLoaded = true;

  const T = window.tailieuTextUtils || {};
  const detector = window.tailieuQuizDetector;
  const course = window.tailieuCourseDetector;
  const matcher = window.tailieuMatcher;
  const highlighter = window.tailieuHighlighter;

  let currentDocumentId = null;
  let detectedDocuments = [];
  let highlightEnabled = true;

  function sendMessage(msg) {
    return new Promise((resolve) => {
      try { chrome.runtime.sendMessage(msg, (r) => resolve(r)); } catch (e) { resolve({ ok: false, error: String(e) }); }
    });
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      try { chrome.storage.local.get(keys, (r) => resolve(r || {})); } catch (e) { resolve({}); }
    });
  }

  function dbg(...a) { if (typeof safeDebugLog === 'function') safeDebugLog('[content]', ...a); }

  async function loadAndHighlight(docId) {
    if (!docId) { dbg('no docId'); return; }
    if (!matcher || !highlighter || !detector) { dbg('modules missing'); return; }

    try {
      const r = await sendMessage({ action: 'getQuestionsByDocument', documentId: docId, useCache: true });
      if (!r || !r.ok) { dbg('fetch questions failed', r && r.error); return; }
      const questions = r.questions || [];
      dbg('loaded', questions.length, 'questions for doc', docId);
      matcher.rebuild(questions);
      dbg('index rebuilt', matcher.getStats());

      if (highlightEnabled) {
        highlighter.clearMarks();
        const parsed = detector.parseQuestions();
        let matchMap = matcher.matchAll(parsed);

        // On-demand fallback: cau hoi chua match local -> search backend (exact+fuzzy).
        const unmatchedTexts = parsed
          .filter((p) => !(matchMap[p.question] && matchMap[p.question].matched))
          .map((p) => p.question)
          .filter(Boolean);
        if (unmatchedTexts.length > 0) {
          dbg('on-demand search for', unmatchedTexts.length, 'unmatched');
          // Stage 1: Tìm trong đúng document trước.
          const s = await sendMessage({ action: 'searchQuestions', questions: unmatchedTexts, documentIds: [docId] });
          let extra = [];
          if (s && s.ok && s.results) {
            Object.keys(s.results).forEach((k) => { (s.results[k] || []).forEach((row) => extra.push(row)); });
          }
          dbg('stage1 search returned', extra.length, 'extra rows');

          // Stage 2: Nếu không tìm được câu nào từ document này → fallback tìm toàn DB.
          // 4th-level fallback trong matcher.matchOne sẽ validate choices (score >= 10) để tránh match sai.
          if (extra.length === 0) {
            dbg('stage2: global search (no documentId filter)');
            const s2 = await sendMessage({ action: 'searchQuestions', questions: unmatchedTexts });
            if (s2 && s2.ok && s2.results) {
              Object.keys(s2.results).forEach((k) => { (s2.results[k] || []).forEach((row) => extra.push(row)); });
            }
            dbg('stage2 search returned', extra.length, 'extra rows');
          }

          if (extra.length > 0) {
            const seen = new Set(questions.map((q) => q.id).filter(Boolean));
            const merged = questions.concat(extra.filter((q) => q.id && !seen.has(q.id)));
            matcher.rebuild(merged);
          }
          matchMap = matcher.matchAll(parsed);
        }

        const res = highlighter.highlightAll(parsed, matchMap);
        dbg('highlight completed', res);
      }
    } catch (e) {
      dbg('Error in loadAndHighlight', e);
    }
  }

  // Load câu hỏi từ nhiều documents (toàn bộ môn học) rồi gộp và highlight.

  async function loadAndHighlightAll(docIds) {
    if (!docIds || docIds.length === 0) { dbg('no docIds'); return; }
    if (!matcher || !highlighter || !detector) { dbg('modules missing'); return; }

    try {
      const r = await sendMessage({ action: 'getQuestionsByDocuments', documentIds: docIds, useCache: true });
      if (!r || !r.ok) {
        dbg('getQuestionsByDocuments failed', r && r.error);
        // Fallback: load document đầu tiên.
        return loadAndHighlight(docIds[0]);
      }
      const questions = r.questions || [];
      dbg('loaded', questions.length, 'questions from', docIds.length, 'docs');
      matcher.rebuild(questions);

      if (highlightEnabled) {
        highlighter.clearMarks();
        const parsed = detector.parseQuestions();
        let matchMap = matcher.matchAll(parsed);

        const unmatchedTexts = parsed
          .filter((p) => !(matchMap[p.question] && matchMap[p.question].matched))
          .map((p) => p.question)
          .filter(Boolean);
        if (unmatchedTexts.length > 0) {
          dbg('on-demand search for', unmatchedTexts.length, 'unmatched (all-docs)');
          // Stage 1: Tìm trong các documents của môn học này.
          const s = await sendMessage({ action: 'searchQuestions', questions: unmatchedTexts, documentIds: docIds });
          let extra = [];
          if (s && s.ok && s.results) {
            Object.keys(s.results).forEach((k) => { (s.results[k] || []).forEach((row) => extra.push(row)); });
          }
          dbg('stage1 search returned', extra.length, 'extra rows');

          // Stage 2: Fallback tìm toàn DB nếu không tìm được trong các docs này.
          if (extra.length === 0) {
            dbg('stage2: global search (all-docs, no documentId filter)');
            const s2 = await sendMessage({ action: 'searchQuestions', questions: unmatchedTexts });
            if (s2 && s2.ok && s2.results) {
              Object.keys(s2.results).forEach((k) => { (s2.results[k] || []).forEach((row) => extra.push(row)); });
            }
            dbg('stage2 search returned', extra.length, 'extra rows');
          }

          if (extra.length > 0) {
            const seen = new Set(questions.map((q) => q.id).filter(Boolean));
            matcher.rebuild(questions.concat(extra.filter((q) => q.id && !seen.has(q.id))));
            matchMap = matcher.matchAll(parsed);
          }
        }


        const res = highlighter.highlightAll(parsed, matchMap);
        dbg('highlight (all-docs) completed', res);
      }
    } catch (e) {
      dbg('Error in loadAndHighlightAll', e);
    }
  }

  async function updateFloatingInfoPopup() {
    let badge = document.getElementById('tailieu-floating-info-badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.id = 'tailieu-floating-info-badge';
      badge.className = 'tlp-floating-badge';
      document.body.appendChild(badge);
    }
    const selectedDoc = detectedDocuments.find(d => d.id === currentDocumentId);
    const docName = selectedDoc ? (selectedDoc.title || selectedDoc.id) : 'Chưa chọn tài liệu';

    try {
      const res = await storageGet(['tailieu_course_info']);
      const courseInfo = res.tailieu_course_info;
      const courseName = courseInfo ? (courseInfo.title || 'Môn học') : 'Không phát hiện môn học';
      badge.innerHTML = `
        <div class="tlp-floating-badge-course" title="${courseName}">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open" style="display:inline-block;vertical-align:middle;margin-right:3px;"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
          <strong>Môn học:</strong> ${courseName}
        </div>
        <div class="tlp-floating-badge-doc" title="${docName}">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-text" style="display:inline-block;vertical-align:middle;margin-right:3px;"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>
          <strong>Tài liệu:</strong> ${docName}
        </div>
      `;
    } catch (e) {
      badge.innerHTML = `
        <div class="tlp-floating-badge-course"><strong>Môn học:</strong> Chưa rõ</div>
        <div class="tlp-floating-badge-doc" title="${docName}"><strong>Tài liệu:</strong> ${docName}</div>
      `;
    }
  }

  async function detectCourseAndLoad() {
    dbg('detectCourseAndLoad start');
    if (!course) { dbg('course detector missing'); return; }
    const info = course.detectCourseInfoFromPage();
    if (!info || !info.title) { dbg('no course title'); return; }
    dbg('course title', info.title);

    // Bước 1: Tìm category (môn học) khớp tên, rồi lấy tất cả documents thuộc category đó.
    const r = await sendMessage({ action: 'getDocumentsByCourseTitle', courseTitle: info.title });
    if (!r || !r.ok) {
      dbg('getDocumentsByCourseTitle failed', r && r.error);
      await updateFloatingInfoPopup();
      return;
    }

    detectedDocuments = r.documents || [];
    if (detectedDocuments.length >= 1) {
      // Chọn document đầu tiên làm mặc định, load câu hỏi từ TẤT CẢ documents của môn học này.
      currentDocumentId = detectedDocuments[0].id;
      await updateFloatingInfoPopup();
      // Load câu hỏi từ tất cả documents cùng lúc để coverage cao hơn.
      if (detectedDocuments.length === 1) {
        await loadAndHighlight(currentDocumentId);
      } else {
        await loadAndHighlightAll(detectedDocuments.map(d => d.id));
      }
    } else {
      dbg('no docs found for course', info.title, '| score:', r._courseScore);
      // Fallback: thử tìm document theo title (luồng cũ).
      const fallback = await sendMessage({ action: 'getDocumentByTitle', title: info.title });
      if (fallback && fallback.ok && (fallback.documents || []).length >= 1) {
        detectedDocuments = fallback.documents;
        currentDocumentId = detectedDocuments[0].id;
        await updateFloatingInfoPopup();
        await loadAndHighlight(currentDocumentId);
      } else {
        await updateFloatingInfoPopup();
      }
    }
  }

  async function syncAuthTokenFromWebApp() {
    const loc = window.location.href;
    const isTailieuWeb = loc.includes('localhost:3000') || loc.includes('tailieu-hou.onrender.com') || loc.includes('tailieu-hou.com');
    if (!isTailieuWeb) return;

    try {
      const supabaseProject = 'fsyvgoltjxfiimoivbwo';
      const key = `sb-${supabaseProject}-auth-token`;
      const sessionStr = localStorage.getItem(key);
      if (sessionStr) {
        const session = JSON.parse(sessionStr);
        if (session && session.access_token) {
          const currentToken = await sendMessage({ action: 'auth:getToken' });
          if (!currentToken || currentToken.token !== session.access_token) {
            const r = await sendMessage({
              action: 'auth:setSession',
              token: session.access_token,
              refreshToken: session.refresh_token,
              user: session.user
            });
            if (r && r.ok) {
              dbg('Dong bo token tu web app thanh cong');
            }
          }
        }
      } else {
        const currentToken = await sendMessage({ action: 'auth:getToken' });
        if (currentToken && currentToken.token) {
          await sendMessage({ action: 'auth:logout' });
          dbg('Dong bo logout tu web app');
        }
      }
    } catch (e) {
      dbg('Loi syncAuthTokenFromWebApp', e);
    }
  }

  // Expose API cho quizMode.js: so sánh câu hỏi trên trang với DB và highlight đáp án
  window._tailieu_manualCompare = async function ({ timeoutMs = 30000 } = {}) {
    if (!detector || !matcher || !highlighter) {
      dbg('_tailieu_manualCompare: modules missing');
      return { matched: [], pageQuestions: [] };
    }
    try {
      let currentQuestions = [];
      if (currentDocumentId) {
        const qr = await sendMessage({ action: 'getQuestionsByDocument', documentId: currentDocumentId, useCache: true });
        if (qr && qr.ok) currentQuestions = qr.questions || [];
      } else if (course) {
        const info = course.detectCourseInfoFromPage();
        if (info && info.title) {
          const r = await sendMessage({ action: 'getDocumentByTitle', title: info.title });
          if (r && r.ok) {
            const docs = r.documents || [];
            if (docs.length >= 1) {
              currentDocumentId = docs[0].id;
              detectedDocuments = docs;
              const qr = await sendMessage({ action: 'getQuestionsByDocument', documentId: currentDocumentId, useCache: true });
              if (qr && qr.ok) currentQuestions = qr.questions || [];
            }
          }
        }
      }

      matcher.rebuild(currentQuestions);

      const parsed = detector.parseQuestions();
      if (!parsed || parsed.length === 0) {
        return { matched: [], pageQuestions: [] };
      }

      let matchMap = matcher.matchAll(parsed);

      const unmatchedTexts = parsed
        .filter((p) => !(matchMap[p.question] && matchMap[p.question].matched))
        .map((p) => p.question)
        .filter(Boolean);
      if (unmatchedTexts.length > 0) {
        console.log('[Matcher Debug] Unmatched texts to search:', unmatchedTexts);
        // Truyền documentIds để backend chỉ tìm trong đúng môn học, tránh match câu sai môn.
        const docIds = (detectedDocuments || []).map(d => d.id).filter(Boolean);
        const s = await sendMessage({ action: 'searchQuestions', questions: unmatchedTexts, documentIds: docIds.length > 0 ? docIds : undefined });
        if (s && s.ok && s.results) {
          const extra = [];
          Object.keys(s.results).forEach((k) => { (s.results[k] || []).forEach((row) => extra.push(row)); });
          if (extra.length > 0) {
            const seen = new Set(currentQuestions.map((q) => q.id).filter(Boolean));
            const merged = currentQuestions.concat(extra.filter((q) => q.id && !seen.has(q.id)));
            matcher.rebuild(merged);
            matchMap = matcher.matchAll(parsed);
          }
        }
      }


      highlighter.clearMarks();
      const res = highlighter.highlightAll(parsed, matchMap);
      dbg('_tailieu_manualCompare highlight result:', res);

      const matched = parsed
        .filter((p) => matchMap[p.question] && matchMap[p.question].matched)
        .map((p) => ({ question: p.question, pageQuestion: p.question, row: matchMap[p.question].row }));

      await updateFloatingInfoPopup();
      return { matched, pageQuestions: parsed };
    } catch (err) {
      dbg('_tailieu_manualCompare error:', err);
      return { matched: [], pageQuestions: [], error: String(err) };
    }
  };

  async function init() {
    await syncAuthTokenFromWebApp();
    
    // Load preference highlight
    const pref = await storageGet(['tailieu_highlight_enabled']);
    highlightEnabled = pref.tailieu_highlight_enabled !== false;

    // Tự động nhận diện môn học và tải tài liệu
    await detectCourseAndLoad();

    // Tự động kiểm tra và đồng bộ token mới 1.5 giây nếu ở trang web app
    const loc = window.location.href;
    const isTailieuWeb = loc.includes('localhost:3000') || loc.includes('tailieu-hou.onrender.com') || loc.includes('tailieu-hou.com');
    if (isTailieuWeb) {
      setInterval(syncAuthTokenFromWebApp, 1500);
    }
  }

  init();
})();
