/**
 * Quiz Mode Handler - Chế độ "Làm bài ngay" cho Tailieu HOU Extension
 * UI: Giống đúng extension gốc (ảnh mẫu)
 * - Nút 🚀 LÀM BÀI NGAY (floating, right center)
 * - Popup kết quả: header gradient xanh, stats màu sắc, chi tiết câu, footer "Trang Tiếp Theo"
 * - Action popup (Làm lại / Đóng) phía dưới popup kết quả
 */
(function () {
  'use strict';

  if (window.tailieuQuizModeLoaded) return;
  window.tailieuQuizModeLoaded = true;

  // ==================== CONSTANTS ====================
  const QUIZ_BUTTON_ID = 'tailieu-quiz-btn';
  const QUIZ_RESULT_POPUP_ID = 'tailieu-quiz-result-popup';
  const QUIZ_ACTION_POPUP_ID = 'tailieu-quiz-action-popup';

  // State
  let isQuizModeActive = false;
  let lastQuizResult = null;
  let quizAutoTriggerTimer = null;

  // ==================== UTILITY ====================

  function isQuizViewPage() {
    try { return String(window.location.pathname || '').indexOf('/mod/quiz/view.php') === 0; } catch (e) { return false; }
  }
  function isQuizAttemptPage() {
    try { return String(window.location.pathname || '').indexOf('/mod/quiz/attempt.php') === 0; } catch (e) { return false; }
  }
  function isQuizReviewPage() {
    try { return String(window.location.pathname || '').indexOf('/mod/quiz/review.php') === 0; } catch (e) { return false; }
  }

  function removeQuizButton() {
    const b = document.getElementById(QUIZ_BUTTON_ID);
    if (b) b.remove();
  }

  function clearQuizAutoTriggerTimer() {
    try { if (quizAutoTriggerTimer) { clearTimeout(quizAutoTriggerTimer); quizAutoTriggerTimer = null; } } catch (e) { quizAutoTriggerTimer = null; }
  }

  function safeAppendToBody(el, cb) {
    if (document.body) { document.body.appendChild(el); if (cb) cb(); }
    else { let n = 0; const t = () => { n++; if (document.body) { document.body.appendChild(el); if (cb) cb(); } else if (n < 50) setTimeout(t, 100); }; t(); }
  }

  function truncateText(text, maxLen) {
    if (!text) return '';
    text = String(text).replace(/<[^>]+>/g, '').trim();
    return text.length > maxLen ? text.substring(0, maxLen - 1) + '…' : text;
  }

  function showNotification(message, type = 'info') {
    const colors = { info: '#3b82f6', success: '#22c55e', warning: '#f59e0b', error: '#ef4444' };
    const n = document.createElement('div');
    n.textContent = message;
    n.style.cssText = `position:fixed;top:20px;right:20px;background:${colors[type]||colors.info};color:white;padding:12px 20px;border-radius:8px;z-index:1000010;font-size:14px;font-family:Arial,sans-serif;box-shadow:0 4px 12px rgba(0,0,0,.25);`;
    safeAppendToBody(n, () => setTimeout(() => { if (n.parentNode) n.remove(); }, 3000));
  }

  // ==================== QUIZ BUTTON ====================

  function createQuizButton() {
    if (isQuizViewPage()) { removeQuizButton(); return null; }
    removeQuizButton();

    const btn = document.createElement('div');
    btn.id = QUIZ_BUTTON_ID;
    btn.innerHTML = `
      <div class="qbtn-content">
        <span class="qbtn-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-rocket"><path d="M4.5 16.5c-1.5 1.25-2.5 3.5-2.5 3.5s2.25-1 3.5-2.5"/><path d="M14 10l-6 6"/><path d="M9 12l.49-.49a2 2 0 0 0 0-2.83L5.41 4.59a2 2 0 0 0-2.83 0L1 6a2 2 0 0 0 0 2.83l4.08 4.08a2 2 0 0 0 2.83 0L8.4 12.4"/><path d="M11.5 9.5l7-7a2 2 0 0 1 2.83 0L23.5 4.7a2 2 0 0 1 0 2.83l-7 7"/><path d="M12 22v-3"/><path d="M19 12h-3"/></svg>
        </span>
        <div class="qbtn-text">
          <span class="qbtn-title">LÀM BÀI</span>
          <span class="qbtn-subtitle">NGAY</span>
        </div>
      </div>
    `;

    btn.addEventListener('mouseenter', () => { btn.style.transform = 'translateY(-50%) scale(1.05)'; });
    btn.addEventListener('mouseleave', () => { btn.style.transform = 'translateY(-50%) scale(1)'; });
    btn.addEventListener('click', async () => {
      clearQuizAutoTriggerTimer();
      btn.style.transform = 'translateY(-50%) scale(0.95)';
      setTimeout(() => { btn.style.transform = 'translateY(-50%) scale(1)'; }, 150);
      await startQuizMode();
    });

    safeAppendToBody(btn);
    return btn;
  }

  function setButtonLoading() {
    const btn = document.getElementById(QUIZ_BUTTON_ID);
    if (!btn) return;
    btn.innerHTML = `
      <div class="qbtn-content">
        <span class="qbtn-icon" style="animation:tlqm-spin 1s linear infinite;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-loader-2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
        </span>
        <div class="qbtn-text">
          <span class="qbtn-title">ĐANG</span>
          <span class="qbtn-subtitle">XỬ LÝ</span>
        </div>
      </div>
    `;
  }

  function resetQuizButton() {
    const btn = document.getElementById(QUIZ_BUTTON_ID);
    if (!btn) return;
    btn.innerHTML = `
      <div class="qbtn-content">
        <span class="qbtn-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-rocket"><path d="M4.5 16.5c-1.5 1.25-2.5 3.5-2.5 3.5s2.25-1 3.5-2.5"/><path d="M14 10l-6 6"/><path d="M9 12l.49-.49a2 2 0 0 0 0-2.83L5.41 4.59a2 2 0 0 0-2.83 0L1 6a2 2 0 0 0 0 2.83l4.08 4.08a2 2 0 0 0 2.83 0L8.4 12.4"/><path d="M11.5 9.5l7-7a2 2 0 0 1 2.83 0L23.5 4.7a2 2 0 0 1 0 2.83l-7 7"/><path d="M12 22v-3"/><path d="M19 12h-3"/></svg>
        </span>
        <div class="qbtn-text">
          <span class="qbtn-title">LÀM BÀI</span>
          <span class="qbtn-subtitle">NGAY</span>
        </div>
      </div>
    `;
  }

  // ==================== TRIGGER COMPARE ====================

  async function triggerManualCompare() {
    return new Promise((resolve) => {
      const ms = 30000;
      if (typeof window._tailieu_manualCompare === 'function') {
        window._tailieu_manualCompare({ timeoutMs: ms }).then(resolve).catch(() => resolve({ matched: [], pageQuestions: [] }));
        return;
      }
      let settled = false;
      const finish = (d) => { if (settled) return; settled = true; document.removeEventListener('tailieu-compare-result', handler); resolve(d); };
      const handler = (e) => finish(e.detail || { matched: [], pageQuestions: [] });
      document.addEventListener('tailieu-compare-result', handler);
      document.dispatchEvent(new CustomEvent('tailieu-trigger-compare'));
      setTimeout(() => finish({ matched: [], pageQuestions: [], timedOut: true }), ms);
    });
  }

  // ==================== PROCESS RESULT (tính stats từ DOM) ====================

  function buildResultFromDOM(rawResult) {
    const containers = Array.from(document.querySelectorAll('div.que, div[id^="q"]')).filter(el =>
      !!(el.querySelector('.formulation') || el.querySelector('.qtext') || el.querySelector('.ablock') || el.querySelector('.answer'))
    );

    let totalFilled = 0;
    let exactMatch = 0;
    let notFound = 0;
    const details = [];

    containers.forEach((container, idx) => {
      let qno = idx + 1;
      const qnoEl = container.querySelector('.qno');
      if (qnoEl) { const n = parseInt((qnoEl.textContent || '').replace(/\D/g, ''), 10); if (!isNaN(n)) qno = n; }

      const qTextEl = container.querySelector('.qtext, .questiontext') || container.querySelector('.formulation');
      const displayText = qTextEl ? (qTextEl.textContent || '').trim() : '';

      const badgeEl = container.querySelector('.tailieu-answer-badge');
      const hasHighlight = !!container.querySelector('.tailieu-correct');
      
      const isNeutralBadge = badgeEl && (badgeEl.classList.contains('tailieu-badge-neutral') || (badgeEl.textContent || '').includes('chưa có đáp án'));
      const filled = (hasHighlight || (badgeEl && !isNeutralBadge));

      let answer = '';
      if (filled) {
        if (badgeEl) answer = (badgeEl.textContent || '').replace(/[✓✅]/g, '').trim();
        if (!answer && hasHighlight) {
          const corr = container.querySelector('.tailieu-correct');
          if (corr) answer = (corr.textContent || '').replace(/^[A-Za-z0-9]\s*[.):\-]\s*/u, '').trim().substring(0, 60);
        }
        totalFilled++;
        exactMatch++;
        details.push({ qno, question: truncateText(displayText, 60), answer: truncateText(answer, 40), status: 'matched', isMatched: true });
      } else {
        const badgeText = badgeEl ? (badgeEl.textContent || '').trim() : 'chưa có đáp án';
        notFound++;
        details.push({ qno, question: truncateText(displayText, 60), answer: badgeText, status: 'not-found', isMatched: false });
      }
    });

    return {
      totalPageQuestions: containers.length,
      totalFilled,
      exactMatch,
      fuzzyMatch: 0,
      notFound,
      dbAnswers: totalFilled,
      aiAnswers: 0,
      details,
    };
  }

  // ==================== RESULT POPUP ====================

  function createResultPopup(result) {
    const existing = document.getElementById(QUIZ_RESULT_POPUP_ID);
    if (existing) existing.remove();

    const { totalPageQuestions, totalFilled, exactMatch, fuzzyMatch, notFound, dbAnswers, aiAnswers, details } = result;

    const popup = document.createElement('div');
    popup.id = QUIZ_RESULT_POPUP_ID;

    const checkIcon = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check" style="display:inline-block;vertical-align:middle;"><path d="M20 6 9 17l-5-5"/></svg>`;
    const crossIcon = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x" style="display:inline-block;vertical-align:middle;"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`;
    const alertIcon = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-alert-triangle" style="display:inline-block;vertical-align:middle;"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;

    popup.innerHTML = `
      <div class="qr-header">
        <span class="qr-header-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bar-chart-2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
        </span>
        <span class="qr-header-title">Kết quả điền đáp án</span>
        <button class="qr-minimize" title="Thu nhỏ">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-minus"><path d="M5 12h14"/></svg>
        </button>
        <button class="qr-close" title="Đóng">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
        </button>
      </div>
      <div class="qr-body">
        <div class="qr-summary">
          <div class="qr-stat-item base">
            <span class="qr-stat-label">Tổng số câu hỏi:</span>
            <span class="qr-stat-value">${totalPageQuestions}</span>
          </div>
          <div class="qr-stat-item filled">
            <span class="qr-stat-icon">${checkIcon}</span>
            <span class="qr-stat-label">Đã điền:</span>
            <span class="qr-stat-value">${totalFilled} câu</span>
          </div>
          <div class="qr-stat-item exact">
            <span class="qr-stat-icon">${checkIcon}</span>
            <span class="qr-stat-label">Khớp chính xác 100%:</span>
            <span class="qr-stat-value">${exactMatch} câu</span>
          </div>
          <div class="qr-stat-item fuzzy">
            <span class="qr-stat-icon">${alertIcon}</span>
            <span class="qr-stat-label">Khớp fuzzy 99.5%:</span>
            <span class="qr-stat-value">${fuzzyMatch} câu</span>
          </div>
          <div class="qr-stat-desc">Vui lòng kiểm tra lại các câu này!</div>
          <div class="qr-stat-item not-found">
            <span class="qr-stat-icon">${crossIcon}</span>
            <span class="qr-stat-label">Không tìm thấy:</span>
            <span class="qr-stat-value">${notFound} câu</span>
          </div>
          <div class="qr-divider"></div>
          <div class="qr-stat-item db">
            <span class="qr-stat-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-database"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/></svg>
            </span>
            <span class="qr-stat-label">Đáp án từ Dữ liệu (DB/Cached):</span>
            <span class="qr-stat-value">${dbAnswers} câu</span>
          </div>
          <div class="qr-stat-item ai">
            <span class="qr-stat-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bot"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>
            </span>
            <span class="qr-stat-label">Đáp án từ AI (Mới):</span>
            <span class="qr-stat-value">${aiAnswers || 0} câu</span>
          </div>
        </div>
        <div class="qr-result-details">
          <div class="qr-details-header">Chi tiết:</div>
          <div class="qr-details-list">
            ${(details || []).map((d, idx) => `
              <div class="qr-detail-item ${d.status}">
                <span class="qr-stat-icon">${d.isMatched ? checkIcon : crossIcon}</span>
                <span class="qr-detail-num">Câu ${idx + 1}:</span>
                <span class="qr-detail-text">${d.question}</span>
                ${d.answer ? `<br><span class="qr-detail-answer">→ ${d.answer}</span>` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      </div>
      <div class="qr-footer">
        <button class="qr-btn-next">Trang Tiếp Theo →</button>
      </div>
    `;

    // Events
    popup.querySelector('.qr-close').addEventListener('click', () => { popup.remove(); removeActionPopup(); });
    popup.querySelector('.qr-minimize').addEventListener('click', () => { popup.remove(); });
    popup.querySelector('.qr-btn-next').addEventListener('click', () => {
      const next = document.querySelector('.mod_quiz-next-nav, [rel="next"], .nextpage a, input[name="next"]');
      if (next) { if (next.tagName === 'INPUT' || next.tagName === 'BUTTON') next.click(); else window.location.href = next.href; }
      else showNotification('Không tìm thấy nút trang tiếp theo.', 'warning');
    });

    safeAppendToBody(popup);
    return popup;
  }

  // ==================== ACTION POPUP ====================

  function removeActionPopup() {
    const e = document.getElementById(QUIZ_ACTION_POPUP_ID);
    if (e) e.remove();
  }

  function createActionPopup() {
    removeActionPopup();

    const popup = document.createElement('div');
    popup.id = QUIZ_ACTION_POPUP_ID;
    popup.innerHTML = `
      <div class="qa-btn qa-retry">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-refresh-cw"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M16 3h5v5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 21H3v-5"/></svg>
        <span>Làm lại</span>
      </div>
      <div class="qa-btn qa-close">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
        <span>Đóng</span>
      </div>
    `;

    popup.querySelector('.qa-retry').addEventListener('click', () => {
      popup.remove();
      const rp = document.getElementById(QUIZ_RESULT_POPUP_ID);
      if (rp) rp.remove();
      createQuizButton();
    });
    popup.querySelector('.qa-close').addEventListener('click', () => {
      popup.remove();
      const rp = document.getElementById(QUIZ_RESULT_POPUP_ID);
      if (rp) rp.remove();
    });

    safeAppendToBody(popup);
    return popup;
  }

  // ==================== MAIN FLOW ====================

  async function startQuizMode() {
    if (window._tailieuQuizModeProcessing) return;
    isQuizModeActive = true;
    window._tailieuQuizModeProcessing = true;
    clearQuizAutoTriggerTimer();
    setButtonLoading();

    try {
      const raw = await triggerManualCompare();

      if (raw && raw.timedOut) { showNotification('Hết thời gian chờ, vui lòng thử lại.', 'warning'); resetQuizButton(); return; }
      if (raw && raw.error) { showNotification('Lỗi khi so sánh: ' + raw.error, 'error'); resetQuizButton(); return; }

      const result = buildResultFromDOM(raw || {});
      lastQuizResult = result;

      createResultPopup(result);
      createActionPopup();
      resetQuizButton();
    } catch (err) {
      console.error('[QuizMode]', err);
      showNotification('Có lỗi: ' + (err && err.message ? err.message : String(err)), 'error');
      resetQuizButton();
    } finally {
      window._tailieuQuizModeProcessing = false;
      isQuizModeActive = false;
    }
  }

  // ==================== INIT ====================

  function initializeQuizMode() {
    if (isQuizAttemptPage() || isQuizReviewPage()) {
      createQuizButton();
    }

    window.tailieuQuizMode = {
      start: startQuizMode,
      isActive: () => isQuizModeActive,
      isEnabled: () => true,
      showResult: createResultPopup,
    };
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    initializeQuizMode();
  } else {
    document.addEventListener('DOMContentLoaded', initializeQuizMode);
  }
})();
