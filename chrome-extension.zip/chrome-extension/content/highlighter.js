// src/content/highlighter.js
// To dap an dung + badge + floating button. No inline styles (CSS o content.css).
(function () {
  'use strict';

  if (window.tailieuHighlighter) return;

  const MARK_ATTR = 'data-tailieu-marked';
  const BADGE_CLASS = 'tailieu-answer-badge';

  // Xoa toan bo marking cu
  function clearMarks() {
    document.querySelectorAll('.tailieu-correct, .tailieu-incorrect, .tailieu-neutral').forEach((el) => {
      el.classList.remove('tailieu-correct', 'tailieu-incorrect', 'tailieu-neutral');
    });
    document.querySelectorAll('.' + BADGE_CLASS).forEach((el) => el.remove());
    document.querySelectorAll('[' + MARK_ATTR + ']').forEach((el) => el.removeAttribute(MARK_ATTR));
  }

  // Tao badge element
  function makeBadge(text, kind) {
    const b = document.createElement('span');
    b.className = BADGE_CLASS + (kind ? ' tailieu-badge-' + kind : '');
    
    // Check if checkmark or cross symbols are needed
    if (text === '✓') {
      b.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check" style="display:inline-block;vertical-align:middle;"><path d="M20 6 9 17l-5-5"/></svg>`;
    } else if (text === '?') {
      b.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-help-circle" style="display:inline-block;vertical-align:middle;"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
    } else {
      b.textContent = text;
    }
    return b;
  }

  // To dap an dung vao 1 .que may.
  function highlightQuestion(parsedQ, matchedRow) {
    if (!parsedQ || !parsedQ.el) return { ok: false };
    const queEl = parsedQ.el;

    if (!matchedRow || !matchedRow.row || !matchedRow.matched) {
      const info = queEl.querySelector('.qtext, .questiontext') || queEl;
      if (info.getAttribute(MARK_ATTR)) return { ok: true, status: 'already' };
      info.setAttribute(MARK_ATTR, '1');
      info.appendChild(makeBadge('chưa có đáp án', 'neutral'));
      return { ok: true, status: 'no-match' };
    }

    const db = matchedRow.row;
    const info = queEl.querySelector('.qtext, .questiontext') || queEl;
    info.setAttribute(MARK_ATTR, '1');

    if (parsedQ.choices && parsedQ.choices.length > 0) {
      const ansText = String(db.answer || '').trim();
      const best = window.tailieuQuizDetector
        ? window.tailieuQuizDetector.findChoiceByAnswer(parsedQ.choices, ansText)
        : null;
      if (best && parsedQ.choiceEls && parsedQ.choiceEls[best.idx]) {
        const target = parsedQ.choiceEls[best.idx];
        target.classList.add('tailieu-correct');
        if (!parsedQ.hasAnswered) {
          const inp = target.querySelector('input');
          if (inp && !inp.checked) inp.checked = true;
        }
        info.appendChild(makeBadge('✓', 'correct'));
        return { ok: true, status: 'highlighted', score: matchedRow.score };
      } else if (!best) {
        // Answer từ DB không match bất kỳ choice nào trên trang:
        // Có thể là câu từ môn khác được match sai, hoặc câu trong DB có answer khác format.
        // Hiển thị "chưa có đáp án" thay vì badge sai gây hiểu nhầm.
        info.appendChild(makeBadge('chưa có đáp án', 'neutral'));
        return { ok: true, status: 'no-match' };
      } else {
        // best tìm được nhưng DOM element bị thiếu → edge case hiếm gặp.
        info.appendChild(makeBadge('không khớp: ' + (ansText.length > 25 ? ansText.substring(0, 22) + '...' : ansText), 'neutral'));
        return { ok: true, status: 'no-match' };
      }
    }



    const ansText = String(db.answer || '').trim();
    if (ansText) {
      info.appendChild(makeBadge(ansText, 'correct'));
      return { ok: true, status: 'badge', score: matchedRow.score };
    }

    info.appendChild(makeBadge('?', 'neutral'));
    return { ok: true, status: 'no-answer' };
  }

  // To hang loat
  function highlightAll(parsedQuestions, matchMap) {
    let count = 0;
    let matched = 0;
    parsedQuestions.forEach((q) => {
      const m = matchMap[q.question] || { matched: false };
      const res = highlightQuestion(q, m);
      count++;
      if (res.status === 'highlighted' || res.status === 'badge') matched++;
    });
    return { total: count, matched };
  }

  // Floating button
  let _btn = null;
  function ensureFloatingButton(onClick) {
    if (_btn && document.body.contains(_btn)) return _btn;
    const btn = document.createElement('button');
    btn.id = 'tailieu-floating-btn';
    btn.type = 'button';
    btn.title = 'Tailieu HOU';
    btn.innerHTML = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-rocket"><path d="M4.5 16.5c-1.5 1.25-2.5 3.5-2.5 3.5s2.25-1 3.5-2.5"/><path d="M14 10l-6 6"/><path d="M9 12l.49-.49a2 2 0 0 0 0-2.83L5.41 4.59a2 2 0 0 0-2.83 0L1 6a2 2 0 0 0 0 2.83l4.08 4.08a2 2 0 0 0 2.83 0L8.4 12.4"/><path d="M11.5 9.5l7-7a2 2 0 0 1 2.83 0L23.5 4.7a2 2 0 0 1 0 2.83l-7 7"/><path d="M12 22v-3"/><path d="M19 12h-3"/></svg>`;
    btn.addEventListener('click', () => { try { onClick && onClick(); } catch (e) {} });
    document.body.appendChild(btn);
    _btn = btn;
    return btn;
  }
  function removeFloatingButton() {
    if (_btn) { _btn.remove(); _btn = null; }
  }

  window.tailieuHighlighter = {
    clearMarks,
    highlightQuestion,
    highlightAll,
    ensureFloatingButton,
    removeFloatingButton,
    MARK_ATTR,
  };
})();
