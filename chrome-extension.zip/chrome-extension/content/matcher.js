// src/content/matcher.js
// Match trang question <-> DB question (exact/clean/lenient index). Port tu content.js rebuildGlobalQuestionIndex.
(function () {
  'use strict';

  if (window.tailieuMatcher) return;

  const T = window.tailieuTextUtils || {};

  let exactIndex = new Map();   // makeKey(text) -> [dbIdx]
  let cleanIndex = new Map();    // cleanText -> [dbIdx]
  let lenientIndex = new Map();  // noSpaceKey -> [dbIdx]
  let dbRows = [];               // normalized cached rows

  // Normalize 1 row: tinh before make keys
  function prepRow(row) {
    const rawQ = (row && row.question) || '';
    const clean = T.cleanQuestionText ? T.cleanQuestionText(rawQ) : String(rawQ).toLowerCase().trim();
    const key = T.makeKey ? T.makeKey(clean) : clean.toLowerCase();
    const noSpace = key ? key.replace(/\s+/g, '') : '';
    return Object.assign({}, row, { _clean: clean, _key: key, _noSpace: noSpace });
  }

  function rebuild(rows) {
    dbRows = (Array.isArray(rows) ? rows : []).map(prepRow).filter(Boolean);
    exactIndex = new Map();
    cleanIndex = new Map();
    lenientIndex = new Map();
    dbRows.forEach((r, idx) => {
      if (r._key) {
        if (!exactIndex.has(r._key)) exactIndex.set(r._key, []);
        exactIndex.get(r._key).push(idx);
      }
      if (r._clean) {
        if (!cleanIndex.has(r._clean)) cleanIndex.set(r._clean, []);
        cleanIndex.get(r._clean).push(idx);
      }
      if (r._noSpace) {
        if (!lenientIndex.has(r._noSpace)) lenientIndex.set(r._noSpace, []);
        lenientIndex.get(r._noSpace).push(idx);
      }
    });
  }

  function pick(idxes) {
    return idxes.map((i) => dbRows[i]);
  }

  function getChoicesOverlapScore(pageChoices, dbChoices, dbAnswer) {
    if (!pageChoices || pageChoices.length === 0) return 0;
    let matchCount = 0;
    
    if (dbChoices && dbChoices.length > 0) {
      const normDbChoices = dbChoices.map(c => String(c).toLowerCase().replace(/\s+/g, '').trim());
      pageChoices.forEach(pc => {
        const normPc = String(pc).toLowerCase().replace(/\s+/g, '').trim();
        if (normDbChoices.some(ndc => ndc.includes(normPc) || normPc.includes(ndc))) {
          matchCount++;
        }
      });
    }
    
    if (dbAnswer) {
      const normAns = String(dbAnswer).toLowerCase().replace(/\s+/g, '').trim();
      const ansMatch = pageChoices.some(pc => {
        const normPc = String(pc).toLowerCase().replace(/\s+/g, '').trim();
        return normPc === normAns || normPc.includes(normAns) || normAns.includes(normPc);
      });
      if (ansMatch) {
        matchCount += 10; // Điểm cộng lớn nếu đáp án trong DB là 1 trong các lựa chọn của trang
      }
    }
    
    return matchCount;
  }

  function findBestCandidate(candidates, pageChoices) {
    if (!candidates || candidates.length === 0) return { row: null, score: 0 };
    
    let best = candidates[0];
    let maxScore = -1;
    
    console.log('[Matcher Debug] findBestCandidate for pageChoices:', pageChoices);
    for (const c of candidates) {
      const score = getChoicesOverlapScore(pageChoices, c.choices || [], c.answer);
      console.log(`[Matcher Debug] Candidate: ID=${c.id}, Q=${c.question?.substring(0, 30)}, Ans=${c.answer?.substring(0, 30)}, Score=${score}`);
      if (score > maxScore) {
        maxScore = score;
        best = c;
      }
    }
    console.log('[Matcher Debug] Best chosen candidate:', best.id, best.answer?.substring(0, 30), 'Score:', maxScore);
    return { row: best, score: maxScore };
  }

  // Match 1 page question -> best matching db row object or null
  function matchOne(pageQuestionText, pageChoices = []) {
    const clean = T.cleanQuestionText ? T.cleanQuestionText(pageQuestionText) : String(pageQuestionText || '').toLowerCase().trim();
    const key = T.makeKey ? T.makeKey(clean) : clean;
    const noSpace = key ? key.replace(/\s+/g, '') : '';

    if (key && exactIndex.has(key)) {
      const { row, score } = findBestCandidate(pick(exactIndex.get(key)), pageChoices);
      if (row && score > 0) return { matched: true, score: 100, row };
    }
    if (clean && cleanIndex.has(clean)) {
      const { row, score } = findBestCandidate(pick(cleanIndex.get(clean)), pageChoices);
      if (row && score > 0) return { matched: true, score: 95, row };
    }
    if (noSpace && lenientIndex.has(noSpace)) {
      const { row, score } = findBestCandidate(pick(lenientIndex.get(noSpace)), pageChoices);
      if (row && score > 0) return { matched: true, score: 85, row };
    }

    // 4th level fallback: tìm trong toàn pool dựa trên choices/answer overlap.
    // Áp dụng khi text không match (câu DB lưu text hơi khác trang), nhưng choices khớp.
    // Yêu cầu score > 0 (có ít nhất 1 choice/answer trùng) để tránh match sai.
    if (pageChoices && pageChoices.length > 0 && dbRows.length > 0) {
      let bestRow = null;
      let bestScore = 0;
      dbRows.forEach((r) => {
        const s = getChoicesOverlapScore(pageChoices, r.choices || [], r.answer);
        if (s > bestScore) { bestScore = s; bestRow = r; }
      });
      if (bestRow && bestScore >= 10) { // score >= 10 = answer chắc chắn khớp với 1 choice
        console.log('[Matcher Debug] 4th-level fallback matched:', bestRow.id, 'Q=', bestRow.question && bestRow.question.substring(0, 40), 'Score:', bestScore);
        return { matched: true, score: 70, row: bestRow };
      }
    }

    return { matched: false, score: 0, row: null };
  }

  // Match nhieu page question -> map
  function matchAll(pageQuestions) {
    const out = {};
    (Array.isArray(pageQuestions) ? pageQuestions : []).forEach((q) => {
      out[q.question] = matchOne(q.question, q.choices);
    });
    return out;
  }

  function getStats() {
    return {
      total: dbRows.length,
      exactKeys: exactIndex.size,
      cleanKeys: cleanIndex.size,
      lenientKeys: lenientIndex.size,
    };
  }

  window.tailieuMatcher = { rebuild, matchOne, matchAll, getStats };
})();

